public class FileSizeCalculatorMain {
    public static void main(String[] args) {
        new FileSizeCalculatorGUI();
    }
}
